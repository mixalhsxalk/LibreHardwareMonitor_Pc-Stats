from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST
from .sensors import MetricCollector
import time

@require_GET
def get_metrics(request):
    """Endpoint for AJAX metric updates"""
    collector = MetricCollector()
    return JsonResponse(collector.collect_metrics())

@csrf_exempt
@require_POST
def reset_max_values(request):
    """Reset all max recorded values and transfer data"""
    MetricCollector.reset_max_cache()
    MetricCollector.reset_transfer_data()
    return JsonResponse({"status": "success"})

@csrf_exempt
@require_POST
def reset_transfer_data(request):
    """Reset network transfer counters"""
    try:
        MetricCollector.reset_transfer_data()
        return JsonResponse({'status': 'success'})
    except Exception as e:
        return JsonResponse(
            {'status': 'error', 'message': str(e)}, 
            status=500
        )

@require_GET
def dashboard_view(request):
    """Main dashboard view with initial data"""
    collector = MetricCollector()
    metrics = collector.collect_metrics()
    
    # Prepare context - simplified structure
    context = {
        "metrics": metrics,
        "timestamp": int(time.time()),
        "card_groups": _prepare_card_groups(metrics),
        "cpu_data": metrics['cpu'],
        "gpu_data": metrics['gpu'],
        "ram_data": metrics['memory'],
        "disk_data": metrics['disk'],
        "network_data": metrics['network'],
    }
    
    return render(request, "dashboard.html", context)

def _prepare_card_groups(metrics: dict) -> dict:
    """Generate card groups structure for the UI dropdown"""
    return {
        'cpu': {
            'label': 'CPU',
            'devices': [cpu['name'] for cpu in metrics['cpu']]
        },
        'gpu': {
            'label': 'GPU',
            'devices': [gpu['name'] for gpu in metrics['gpu']]
        },
        'ram': {
            'label': 'RAM',
            'devices': ['System RAM']
        },
        'disk': {
            'label': 'Storage',
            'devices': [disk['name'] for disk in metrics['disk']['devices']]
        },
        'network': {
            'label': 'Network',
            'devices': [nic['name'] for nic in metrics['network']['interfaces']]
        }
    }
