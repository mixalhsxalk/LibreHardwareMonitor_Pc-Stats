import os
import json
import time
import psutil
import requests
from pathlib import Path
from datetime import datetime
from threading import Lock
from typing import Dict, List, Optional, Union
from django.conf import settings

class JSONSensorMonitor:
    def __init__(self):
        self.cache = {}
        self.cache_lock = Lock()
        self.last_updated = 0
        self.refresh_interval = 1.0
        
        # Structured max values tracking
        self.max_values = {
            'cpu': {'usage': 0, 'temp': 0, 'power': 0, 'voltage': 0},
            'gpu': {'core': 0, 'memory': 0, 'temp': 0, 'hotspot': 0, 'power': 0}, 
            'memory': {'usage': 0},
            'disk': {'read': 0, 'write': 0, 'temp': 0},
            'network': {'download': 0, 'upload': 0}
        }
        self.max_lock = Lock()

    def _fetch_json_data(self) -> Optional[dict]:
        """Fetch data from LHM API with proper error handling"""
        url = getattr(settings, 'LHM_API_URL', 'http://localhost:8085/data.json')
        try:
            response = requests.get(url, timeout=2.0)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"LHM API Error: {str(e)}")
            return None
        except json.JSONDecodeError as e:
            print(f"Invalid JSON from LHM: {str(e)}")
            return None

    def _refresh_cache(self):
        """Refresh cached data with thread safety"""
        data = self._fetch_json_data()
        if not data:
            return

        flat_data = {}
        
        def flatten_sensors(node, path=""):
            """Recursively flatten sensor tree"""
            if not isinstance(node, dict):
                return
                
            label = node.get("Text", "")
            sensor_type = node.get("Type")
            value = node.get("Value")
            
            if all([label, sensor_type, value is not None]):
                flat_data[f"{path}/{label}" if path else label] = {
                    'value': value,
                    'type': sensor_type
                }

            for child in node.get("Children", []):
                flatten_sensors(child, f"{path}/{label}" if path else label)

        flatten_sensors(data)
        
        with self.cache_lock:
            self.cache = flat_data
            self.last_updated = time.time()

    def get_sensor_value(
        self,
        device_name: str,
        sensor_name: str,
        sensor_type: str = None
    ) -> float:
        """
        Unified sensor value getter with device context
        
        Args:
            device_name: Partial match of device name (e.g. "RTX 3080")
            sensor_name: Partial match of sensor name (e.g. "Core Temp")
            sensor_type: Optional type filter (e.g. "Temperature")
            
        Returns:
            float: Sensor value or 0.0 if not found
        """
        if time.time() - self.last_updated > self.refresh_interval:
            self._refresh_cache()

        with self.cache_lock:
            for path, sensor in self.cache.items():
                path_lower = path.lower()
                matches_device = device_name.lower() in path_lower
                matches_sensor = sensor_name.lower() in path_lower
                matches_type = (not sensor_type or 
                              sensor_type.lower() == sensor['type'].lower())
                
                if matches_device and matches_sensor and matches_type:
                    try:
                        value = str(sensor['value']).replace(",", ".").split()[0]
                        return float(value)
                    except (ValueError, AttributeError):
                        continue
        return 0.0

    def get_avg_cpu_core_voltage(self) -> float:
        """Get average voltage across all CPU cores"""
        if time.time() - self.last_updated > self.refresh_interval:
            self._refresh_cache()

        voltages = []
        with self.cache_lock:
            for path, sensor in self.cache.items():
                if "CPU Core #" in path and "Voltage" in path:
                    try:
                        value = str(sensor['value']).replace(",", ".").split()[0]
                        voltages.append(float(value))
                    except (ValueError, AttributeError):
                        continue
        
        return sum(voltages) / len(voltages) if voltages else 0.0

    def get_avg_cpu_core_load(self) -> float:
        """Get average load across all CPU cores"""
        if time.time() - self.last_updated > self.refresh_interval:
            self._refresh_cache()

        loads = []
        with self.cache_lock:
            for path, sensor in self.cache.items():
                if "CPU Core #" in path and sensor['type'].lower() == "load":
                    try:
                        value = str(sensor['value']).replace(",", ".").split()[0]
                        loads.append(float(value))
                    except (ValueError, AttributeError):
                        continue
        
        return sum(loads) / len(loads) if loads else 0.0

    def update_max_values(self, metrics: dict):
        """Update max values tracking in a thread-safe way"""
        with self.max_lock:
            # CPU
            for cpu in metrics.get('cpu', []):
                for metric in ['usage', 'temp', 'power', 'voltage','hotspot']:
                    if metric in cpu and cpu[metric] > self.max_values['cpu'].get(metric, 0):
                        self.max_values['cpu'][metric] = cpu[metric]
            
            # GPU
            for gpu in metrics.get('gpu', []):
                for metric in ['core', 'temp', 'power']:
                    if metric in gpu and gpu[metric] > self.max_values['gpu'].get(metric, 0):
                        self.max_values['gpu'][metric] = gpu[metric]
            
            # Disk
            for disk in metrics.get('disk', {}).get('devices', []):
                if disk['read'] > self.max_values['disk']['read']:
                    self.max_values['disk']['read'] = disk['read']
                if disk['write'] > self.max_values['disk']['write']:
                    self.max_values['disk']['write'] = disk['write']
                if disk['temp'] > self.max_values['disk']['temp']:
                    self.max_values['disk']['temp'] = disk['temp']
            
            # Network
            for nic in metrics.get('network', {}).get('interfaces', []):
                if nic['download'] > self.max_values['network']['download']:
                    self.max_values['network']['download'] = nic['download']
                if nic['upload'] > self.max_values['network']['upload']:
                    self.max_values['network']['upload'] = nic['upload']

    def reset_max_values(self):
        """Reset all max values to 0"""
        with self.max_lock:
            for category in self.max_values:
                for metric in self.max_values[category]:
                    self.max_values[category][metric] = 0


class MetricCollector:
    _instance = None
    _lock = Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
            
        self._initialized = True
        self.sensor_monitor = JSONSensorMonitor()
        self._init_network_counters()
        self.system_drive = os.getenv("SystemDrive", "C:") + "\\"
        self.device_map = self._load_device_map()
        self.category_devices = self._group_devices_by_category()

    def _init_network_counters(self):
        """Initialize network tracking"""
        current_net = psutil.net_io_counters(pernic=True)
        self.prev_net = {iface: {
            'sent': counters.bytes_sent,
            'recv': counters.bytes_recv
        } for iface, counters in current_net.items()}
        
        self.transfer_offset = {iface: {
            'sent': counters.bytes_sent,
            'recv': counters.bytes_recv
        } for iface, counters in current_net.items()}
        self.prev_net_time = time.time()

    def _load_device_map(self) -> dict:
        """Load and validate device category map"""
        path = Path("device_category_map.json")
        if not path.exists():
            print("Warning: device_category_map.json not found - using fallback detection")
            return self._get_fallback_device_map()

        try:
            with open(path, 'r') as f:
                device_map = json.load(f)
                
            if not isinstance(device_map, dict):
                raise ValueError("Device map should be a dictionary")
                
            return device_map
        except Exception as e:
            print(f"Error loading device map: {str(e)}")
            return self._get_fallback_device_map()

    def _get_fallback_device_map(self) -> dict:
        """Fallback device detection when map file is missing"""
        data = self.sensor_monitor._fetch_json_data()
        if not data:
            return {}
            
        device_map = {}
        keyword_map = {
            "CPU": ["intel", "amd", "ryzen", "core"],
            "GPU": ["nvidia", "geforce", "radeon"],
            "Storage": ["samsung", "wd", "seagate"],
            "Network": ["ethernet", "wifi", "realtek"]
        }

        def scan_node(node):
            name = node.get("Text", "")
            for category, keywords in keyword_map.items():
                if any(k.lower() in name.lower() for k in keywords):
                    device_map[name] = category
                    break
            for child in node.get("Children", []):
                scan_node(child)

        scan_node(data)
        return device_map

    def _group_devices_by_category(self) -> dict:
        """Organize devices by standardized categories"""
        categories = {
            'cpu': [],
            'gpu': [],
            'memory': ["System RAM"],
            'disk': [],
            'network': []
        }
        
        category_mapping = {
            'CPU': 'cpu',
            'GPU': 'gpu',
            'Storage': 'disk',
            'Network': 'network'
        }

        for device, category in self.device_map.items():
            normalized_category = category_mapping.get(category)
            if normalized_category:
                categories[normalized_category].append(device)
                
        return categories

    def collect_metrics(self) -> dict:
        """Main metrics collection method"""
        metrics = {
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'cpu': self._collect_cpu_metrics(),
            'gpu': self._collect_gpu_metrics(),
            'memory': self._collect_memory_metrics(),
            'disk': self._collect_disk_metrics(),
            'network': self._collect_network_metrics(),
            'max_values': self.sensor_monitor.max_values
        }
        
        self.sensor_monitor.update_max_values(metrics)
        return metrics

    def _collect_cpu_metrics(self) -> List[dict]:
        """Collect metrics for all CPU devices"""
        metrics = []
        for device in self.category_devices['cpu']:
            metrics.append({
                'name': device,
                'usage': self.sensor_monitor.get_sensor_value(device, "CPU Total", "Load") or 
                         psutil.cpu_percent(interval=0.1),
                'temp': self.sensor_monitor.get_sensor_value(device, "Package", "Temperature"),
                'power': self.sensor_monitor.get_sensor_value(device, "Package", "Power"),
                'voltage': self.sensor_monitor.get_sensor_value(device, "Core", "Voltage") or 
                          self.sensor_monitor.get_avg_cpu_core_voltage(),
                'avg_core_load': self.sensor_monitor.get_avg_cpu_core_load()
            })
        return metrics if metrics else [{
            'name': "CPU",
            'usage': psutil.cpu_percent(interval=0.1),
            'temp': 0,
            'power': 0,
            'voltage': self.sensor_monitor.get_avg_cpu_core_voltage(),
            'avg_core_load': self.sensor_monitor.get_avg_cpu_core_load()
        }]

    def _collect_gpu_metrics(self) -> List[dict]:
        """Collect metrics for all GPU devices"""
        metrics = []
        for device in self.category_devices['gpu']:
            metrics.append({
                'name': device,
                'core': self.sensor_monitor.get_sensor_value(device, "Core", "Load"),
                'memory': self.sensor_monitor.get_sensor_value(device, "Memory", "Load"),
                'temp': self.sensor_monitor.get_sensor_value(device, "Core", "Temperature"),
                'power': self.sensor_monitor.get_sensor_value(device, "GPU", "Power"),
                'hotspot': self.sensor_monitor.get_sensor_value(device, "Hotspot", "Temperature") or  # New
                      self.sensor_monitor.get_sensor_value(device, "Hot Spot", "Temperature") or  # Alternate naming
                      self.sensor_monitor.get_sensor_value(device, "Junction", "Temperature"),   # AMD naming
            })
        return metrics if metrics else [{
            'name': "GPU",
            'core': 0,
            'memory': 0,
            'temp': 0,
            'hotspot': 0,
            'power': 0
        }]

    def _collect_memory_metrics(self) -> dict:
        """Collect system memory metrics"""
        mem = psutil.virtual_memory()
        return {
            'name': "System RAM",
            'usage': mem.percent,
            'total': mem.total,
            'used': mem.used,
            'free': mem.free
        }

    def _collect_disk_metrics(self) -> dict:
        """Collect disk metrics without duplicates - final version"""
        disks = []
        disk_io = self._get_disk_io()
        
        # Create mapping between LHM names and psutil names
        matched_psutil_disks = set()
        
        # Process all LHM-monitored disks first
        for lhm_disk in self.category_devices['disk']:
            # Find best matching psutil disk
            psutil_name = self._find_matching_psutil_disk(lhm_disk, disk_io)
            
            disk_data = {
                'name': lhm_disk,
                'temp': self.sensor_monitor.get_sensor_value(lhm_disk, "Temperature"),
                'read': disk_io[psutil_name]['read_speed'] if psutil_name else 0,
                'write': disk_io[psutil_name]['write_speed'] if psutil_name else 0,
                'device': psutil_name if psutil_name else lhm_disk
            }
            disks.append(disk_data)
            
            if psutil_name:
                matched_psutil_disks.add(psutil_name)
        
        # Add unmatched psutil disks (without temperature)
        for psutil_name, io_data in disk_io.items():
            if psutil_name not in matched_psutil_disks:
                disks.append({
                    'name': psutil_name,
                    'temp': 0,
                    'read': io_data['read_speed'],
                    'write': io_data['write_speed'],
                    'device': psutil_name
                })
        
        return {'devices': disks}

    def _find_matching_psutil_disk(self, lhm_disk, disk_io):
        """Find matching psutil disk using multiple strategies"""
        lhm_lower = lhm_disk.lower()
        
        # Strategy 1: Exact model matching (e.g. "KINGSTON" in both names)
        for psutil_name in disk_io.keys():
            psutil_lower = psutil_name.lower()
            if ('physicaldrive' in psutil_lower and 
                any(brand in lhm_lower for brand in ['samsung', 'kingston', 'wd', 'seagate'])) or \
            (psutil_lower in lhm_lower) or \
            (lhm_lower in psutil_lower):
                return psutil_name
        
        # Strategy 2: Drive letter matching (e.g. "C:" in LHM name)
        drive_letter_map = self._map_drive_letters_to_physical()
        for letter, physical_drive in drive_letter_map.items():
            if letter in lhm_disk and physical_drive in disk_io:
                return physical_drive
        
        return None

    def _map_drive_letters_to_physical(self):
        """Map Windows drive letters to PhysicalDrive numbers"""
        drive_map = {}
        try:
            for part in psutil.disk_partitions():
                if 'cdrom' in part.opts.lower():
                    continue
                if part.device and 'PhysicalDrive' in part.device:
                    drive_letter = part.mountpoint[0].upper() + ':'
                    drive_map[drive_letter] = part.device.split('\\')[-1]
        except Exception:
            pass
        return drive_map

    def _get_disk_io(self) -> dict:
        """Get disk I/O statistics"""
        current_disk = psutil.disk_io_counters(perdisk=True)
        current_time = time.time()

        # First-time setup if not already initialized
        if not hasattr(self, 'prev_disk') or not hasattr(self, 'prev_disk_time'):
            self.prev_disk = {disk: {'read': c.read_bytes, 'write': c.write_bytes} 
                              for disk, c in current_disk.items()}
            self.prev_disk_time = current_time
            return {}  # No deltas yet

        time_diff = max(current_time - self.prev_disk_time, 0.1)

        io_data = {}
        for disk, counters in current_disk.items():
            prev_counters = self.prev_disk.get(disk)
            if prev_counters:
                io_data[disk] = {
                    'read_speed': (counters.read_bytes - prev_counters['read']) / time_diff,
                    'write_speed': (counters.write_bytes - prev_counters['write']) / time_diff
                }

        self.prev_disk = {disk: {'read': c.read_bytes, 'write': c.write_bytes} 
                          for disk, c in current_disk.items()}
        self.prev_disk_time = current_time
        return io_data

    def _collect_network_metrics(self) -> dict:
        """Collect metrics for all network interfaces"""
        psutil_net = self._get_network_usage()
        
        interfaces = []
        # Get LHM-monitored network devices
        for device in self.category_devices['network']:
            interfaces.append({
                'name': device,
                'speed': self.sensor_monitor.get_sensor_value(device, "Speed"),
                'upload': 0,
                'download': 0,
                'bytes_sent': 0,
                'bytes_recv': 0,
                'interface': device
            })
        
        # Merge with active psutil interfaces
        for iface, net_data in psutil_net.items():
            # Try to find matching interface by name
            matching_nic = None
            for nic in interfaces:
                if iface.lower() in nic['name'].lower() or nic['name'].lower() in iface.lower():
                    matching_nic = nic
                    break
            
            if matching_nic:
                # Update existing entry
                matching_nic.update({
                    'upload': net_data['upload_speed'],
                    'download': net_data['download_speed'],
                    'bytes_sent': net_data['bytes_sent'],
                    'bytes_recv': net_data['bytes_recv'],
                    'interface': iface
                })
            else:
                # Add active interfaces not in device map
                if net_data['upload_speed'] + net_data['download_speed'] > 0:
                    interfaces.append({
                        'name': iface,
                        'speed': 0,
                        'upload': net_data['upload_speed'],
                        'download': net_data['download_speed'],
                        'bytes_sent': net_data['bytes_sent'],
                        'bytes_recv': net_data['bytes_recv'],
                        'interface': iface
                    })
        
        return {'interfaces': interfaces}

    def _get_network_usage(self) -> dict:
        """Get network usage statistics"""
        current_time = time.time()
        current_net = psutil.net_io_counters(pernic=True)
        
        # Initialize if not already done
        if not hasattr(self, 'prev_net') or not hasattr(self, 'prev_net_time'):
            self.prev_net = {iface: {'sent': counters.bytes_sent, 'recv': counters.bytes_recv} 
                            for iface, counters in current_net.items()}
            self.prev_net_time = current_time
            return {}

        time_diff = max(current_time - self.prev_net_time, 0.1)
        
        usage = {}
        for iface, counters in current_net.items():
            prev = self.prev_net.get(iface, {'sent': 0, 'recv': 0})
            offset = self.transfer_offset.get(iface, {'sent': 0, 'recv': 0})
            
            usage[iface] = {
                'upload_speed': max(0, (counters.bytes_sent - prev['sent']) / time_diff),
                'download_speed': max(0, (counters.bytes_recv - prev['recv']) / time_diff),
                'bytes_sent': counters.bytes_sent - offset['sent'],  # Total sent since last reset
                'bytes_recv': counters.bytes_recv - offset['recv'],  # Total received since last reset
                'interface': iface
            }
        
        self.prev_net = {iface: {'sent': c.bytes_sent, 'recv': c.bytes_recv} 
                        for iface, c in current_net.items()}
        self.prev_net_time = current_time
        return usage

    @classmethod
    def reset_max_cache(cls):
        instance = cls()
        instance.sensor_monitor.reset_max_values()

    @classmethod
    def reset_transfer_data(cls):
        instance = cls()
        instance._init_network_counters()
