from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard_view, name='dashboard'),
    path('reset_max_values/', views.reset_max_values, name='reset_max_values'),
    path('reset_transfer_data/', views.reset_transfer_data, name='reset_transfer_data'),
    path('get_metrics/', views.get_metrics, name='get_metrics'),
    path('reset_transfer_data/', views.reset_transfer_data, name='reset_transfer_data'),
]