const CARD_VISIBILITY_KEY = 'dashboardCardVisibility';
const THEMES = {
  dark: { icon: '🌙', name: 'Dark' },
  light: { icon: '☀️', name: 'Light' }
};
const themeKeys = Object.keys(THEMES);
let currentThemeIndex = 0;

// Utility Functions
function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
}

function toggleCardVisibility(group, device, show) {
  const selector = `.card[data-group="${group}"][data-device="${CSS.escape(device)}"]`;
  const cards = document.querySelectorAll(selector);
  cards.forEach(card => {
    card.style.display = show ? '' : 'none';
  });
}

// Card Visibility Management
function initializeCardVisibility() {
  const selectorDropdown = document.getElementById('card-selector');
  const cardSelectorBtn = document.getElementById('card-selector-btn');
  if (!selectorDropdown || !cardSelectorBtn) return;

  const savedVisibility = JSON.parse(localStorage.getItem(CARD_VISIBILITY_KEY)) || {};
  const checkboxes = selectorDropdown.querySelectorAll('.toggle-group');
  checkboxes.forEach(checkbox => {
    const group = checkbox.dataset.group;
    const device = checkbox.dataset.device;
    const cardId = `${group}-${device}`.toLowerCase();
    const isVisible = savedVisibility[cardId] !== false;
    checkbox.checked = isVisible;
    toggleCardVisibility(group, device, isVisible);
  });

  cardSelectorBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    selectorDropdown.classList.toggle('show');
  });

  selectorDropdown.addEventListener('change', (e) => {
    if (e.target.classList.contains('toggle-group')) {
      const group = e.target.dataset.group;
      const device = e.target.dataset.device;
      const cardId = `${group}-${device}`.toLowerCase();
      const isVisible = e.target.checked;
      toggleCardVisibility(group, device, isVisible);
      const visibility = JSON.parse(localStorage.getItem(CARD_VISIBILITY_KEY)) || {};
      visibility[cardId] = isVisible;
      localStorage.setItem(CARD_VISIBILITY_KEY, JSON.stringify(visibility));
    }
  });

  document.addEventListener('click', (e) => {
    if (!selectorDropdown.contains(e.target) && e.target !== cardSelectorBtn) {
      selectorDropdown.classList.remove('show');
    }
  });
}

// Theme Management
function initializeTheme() {
  const savedTheme = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = savedTheme || (prefersDark ? 'dark' : 'light');
  applyTheme(theme);
}

function applyTheme(theme) {
  if (!THEMES[theme]) return;
  document.documentElement.removeAttribute('data-theme');
  document.documentElement.setAttribute('data-theme', theme);
  const themeBtn = document.getElementById('themeBtn');
  if (themeBtn) {
    const iconEl = themeBtn.querySelector('.btn-icon');
    if (iconEl) {
      iconEl.textContent = THEMES[theme].icon;
    }
    currentThemeIndex = themeKeys.indexOf(theme);
  }
  localStorage.setItem('theme', theme);
}

function setupThemeSwitcher() {
  const themeBtn = document.getElementById('themeBtn');
  if (!themeBtn) return;
  themeBtn.addEventListener('click', () => {
    currentThemeIndex = (currentThemeIndex + 1) % themeKeys.length;
    const nextTheme = themeKeys[currentThemeIndex];
    applyTheme(nextTheme);
  });
}

// Reset Handler
function setupResetHandler() {
  const resetBtn = document.getElementById('resetBtn');
  if (!resetBtn) return;

  resetBtn.addEventListener('click', async () => {
    try {
      const maxResponse = await fetch('/reset_max_values/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': getCookie('csrftoken')
        }
      });

      const transferResponse = await fetch('/reset_transfer_data/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': getCookie('csrftoken')
        }
      });

      if (maxResponse.ok && transferResponse.ok) {
        resetBtn.innerHTML = '<span class="btn-icon">✓</span> <span>Done</span>';
        setTimeout(() => {
          resetBtn.innerHTML = '<span class="btn-icon">⟳</span> <span>Reset</span>';
        }, 2000);
        pollMetrics();
      }
    } catch (e) {
      console.error('Reset error:', e);
    }
  });
}

// Stats Dropdown Management
function initializeStatsDropdowns() {
  document.querySelectorAll('.stats-select').forEach(select => {
    select.addEventListener('change', function () {
      const type = this.dataset.type;
      const selectedDevice = this.value;
      localStorage.setItem(`selected_${type}`, selectedDevice);
    });
    const type = select.dataset.type;
    const savedSelection = localStorage.getItem(`selected_${type}`);
    if (savedSelection) select.value = savedSelection;
  });
}

// Metrics Polling
function startMetricsPolling() {
  function updateTime() {
    const timeElement = document.getElementById('header-time');
    if (timeElement) timeElement.textContent = new Date().toLocaleTimeString();
  }
  updateTime();
  setInterval(updateTime, 1000);

  async function pollMetrics() {
    try {
      const res = await fetch('/get_metrics/');
      const data = await res.json();

      const selectedCpu = document.querySelector('.stats-select[data-type="cpu"]')?.value;
      const cpuData = data.cpu?.find(cpu => cpu.name === selectedCpu) || data.cpu?.[0];
      if (cpuData) {
        const element = document.getElementById('header-cpu-usage');
        if (element) element.textContent = `${cpuData.usage?.toFixed(1) || 0}%`;
      }

      const selectedGpu = document.querySelector('.stats-select[data-type="gpu"]')?.value;
      const gpuData = data.gpu?.find(gpu => gpu.name === selectedGpu) || data.gpu?.[0];
      if (gpuData) {
        const element = document.getElementById('header-gpu-usage');
        if (element) element.textContent = `${gpuData.core?.toFixed(1) || 0}%`;
      }

      if (data.memory) {
        const element = document.getElementById('header-ram-usage');
        if (element) element.textContent = `${data.memory.usage?.toFixed(1) || 0}%`;
      }

      const selectedNetwork = document.querySelector('.stats-select[data-type="network"]')?.value;
      const networkData = data.network?.interfaces?.find(nic =>
        nic.name === selectedNetwork || nic.interface === selectedNetwork
      ) || data.network?.interfaces?.[0];
      if (networkData) {
        const element = document.getElementById('header-network-usage');
        if (element) {
          const formatData = (bytes) => {
            if (bytes < 1024) return `${bytes.toFixed(1)} B`;
            if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
            if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
            return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
          };
          const sent = formatData(networkData.bytes_sent || 0);
          const recv = formatData(networkData.bytes_recv || 0);
          element.textContent = `↑ ${sent} ↓ ${recv}`;
        }
      }

      document.dispatchEvent(new CustomEvent('metricsUpdate', { detail: data }));
    } catch (e) {
      console.error('Polling error:', e);
    }
    setTimeout(pollMetrics, 1000);
  }
  pollMetrics();
}


function resizeDashboardToFit() {
  const isMobile = window.innerWidth < 992;
  const container = document.querySelector('.dashboard-container');

  if (!container) return;

  // Reset any previous scale or overflow styles
  container.style.transform = '';
  container.style.transformOrigin = '';
  container.style.margin = '';
  document.body.style.overflow = '';

  if (isMobile) {
    // Allow normal scrolling on mobile
    container.style.width = '';
    document.body.style.overflow = 'auto';
    console.log('[Dashboard Resize] Mobile mode — scrollbars enabled.');
    return;
  }

  // Calculate scaling factor and clamp it
  const bodyHeight = document.body.scrollHeight;
  const windowHeight = window.innerHeight;
  let scale = windowHeight / bodyHeight;
  scale = Math.max(0.5, Math.min(1, scale)); // Clamp scale between 0.5 and 1

  // Apply scaling transform
  container.style.transform = `scale(${scale})`;
  container.style.transformOrigin = 'top center';
  container.style.margin = '0 auto';
  document.body.style.overflow = 'hidden'; // Hide scrollbars

  console.log(`[Dashboard Resize] Scaling applied: ${scale.toFixed(2)}`);
}

// Throttle resize handler to avoid performance issues
let resizeTimeout;
function handleThrottledResize() {
  clearTimeout(resizeTimeout);
  resizeTimeout = setTimeout(resizeDashboardToFit, 100);
}

window.addEventListener('resize', handleThrottledResize);
window.addEventListener('load', resizeDashboardToFit);


// Initialize everything
document.addEventListener('DOMContentLoaded', () => {
  initializeTheme();
  setupThemeSwitcher();
  initializeCardVisibility();
  setupResetHandler();
  initializeStatsDropdowns();
  startMetricsPolling();
});