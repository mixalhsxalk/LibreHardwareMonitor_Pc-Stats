/**
 * Dashboard Management System - Fully Optimized Version
 * 
 * Features:
 * - Perfect centering in both auto-resize and fixed modes
 * - Optimal card arrangement with CSS Grid
 * - Comprehensive responsive handling
 * - Robust error handling
 * - Smooth transitions between states
 */

// Constants
const CARD_VISIBILITY_KEY = 'dashboardCardVisibility';
const AUTO_RESIZE_KEY = 'dashboardAutoResize';
const RESIZE_REFRESHED_KEY = 'hasResizedOnce';
const REFRESH_COOLDOWN_DURATION = 5000; // 5 seconds
const MOBILE_BREAKPOINT = 992;
const DEBOUNCE_DELAY = 200;

const THEMES = {
  dark: { icon: '🌙', name: 'Dark' },
  light: { icon: '☀️', name: 'Light' }
};

// State Management
const state = {
  autoResizeEnabled: true,
  currentThemeIndex: 0,
  lastSize: {
    width: window.innerWidth,
    height: window.innerHeight
  },
  pendingRefresh: false,
  resizeCooldown: false,
  resizeTimeout: null,
  isMobile: window.innerWidth < MOBILE_BREAKPOINT,
  initialized: false
};

// Utility Functions
const utils = {
  getCookie(name) {
    try {
      const value = `; ${document.cookie}`;
      const parts = value.split(`; ${name}=`);
      if (parts.length === 2) return parts.pop().split(';').shift();
      return null;
    } catch (e) {
      console.error('Cookie error:', e);
      return null;
    }
  },

  throttle(fn, delay) {
    let lastCall = 0;
    return function(...args) {
      const now = Date.now();
      if (now - lastCall < delay) return;
      lastCall = now;
      return fn(...args);
    };
  },

  formatBytes(bytes) {
    if (typeof bytes !== 'number' || isNaN(bytes)) return '0 B';
    if (bytes < 1024) return `${bytes.toFixed(1)} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
  },

  applyOptimalLayoutStyles(container, isFixedLayout = false) {
    if (!container) return;
    
    try {
      container.style.width = 'min(95vw, 1600px)';
      container.style.margin = '0 auto';
      container.style.padding = '20px';
      container.style.boxSizing = 'border-box';
      container.style.display = 'grid';
      container.style.gridTemplateColumns = 'repeat(auto-fit, minmax(300px, 1fr))';
      container.style.gap = '20px';
      container.style.alignItems = 'start';
      
      document.querySelectorAll('.card').forEach(card => {
        card.style.minWidth = '300px';
        card.style.maxWidth = '100%';
        card.style.margin = '0';
      });
      
      document.body.style.overflow = isFixedLayout ? 'auto' : 'hidden';
    } catch (e) {
      console.error('Layout style error:', e);
    }
  },

  resetLayoutStyles(container) {
    if (!container) return;
    
    try {
      container.style.width = '';
      container.style.margin = '';
      container.style.padding = '';
      container.style.display = '';
      container.style.gridTemplateColumns = '';
      container.style.gap = '';
      container.style.alignItems = '';
      container.style.transform = '';
      container.style.transformOrigin = '';
      document.body.style.overflow = '';
    } catch (e) {
      console.error('Reset style error:', e);
    }
  },

  safeParseJSON(str) {
    try {
      return JSON.parse(str);
    } catch (e) {
      console.error('JSON parse error:', e);
      return {};
    }
  }
};

// Card Visibility Module
const cardVisibility = {
  init() {
    try {
      const selectorDropdown = document.getElementById('card-selector');
      const cardSelectorBtn = document.getElementById('card-selector-btn');
      if (!selectorDropdown || !cardSelectorBtn) return;

      this.loadVisibilityStates();
      this.setupEventListeners(selectorDropdown, cardSelectorBtn);
    } catch (e) {
      console.error('Card visibility init error:', e);
    }
  },

  loadVisibilityStates() {
    try {
      const savedVisibility = utils.safeParseJSON(localStorage.getItem(CARD_VISIBILITY_KEY));
      const checkboxes = document.querySelectorAll('.toggle-group');
      
      checkboxes.forEach(checkbox => {
        const group = checkbox.dataset.group;
        const device = checkbox.dataset.device;
        const cardId = `${group}-${device}`.toLowerCase();
        const isVisible = savedVisibility[cardId] !== false;
        
        checkbox.checked = isVisible;
        this.toggleCardVisibility(group, device, isVisible);
      });
    } catch (e) {
      console.error('Load visibility error:', e);
    }
  },

  toggleCardVisibility(group, device, show) {
    try {
      const selector = `.card[data-group="${group}"][data-device="${CSS.escape(device)}"]`;
      const cards = document.querySelectorAll(selector);
      
      cards.forEach(card => {
        card.style.display = show ? '' : 'none';
      });
    } catch (e) {
      console.error('Toggle visibility error:', e);
    }
  },

  setupEventListeners(dropdown, button) {
    try {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('show');
      });

      dropdown.addEventListener('change', (e) => {
        if (e.target.classList.contains('toggle-group')) {
          this.handleCardToggle(e.target);
        }
      });

      document.addEventListener('click', (e) => {
        if (!dropdown.contains(e.target) && e.target !== button) {
          dropdown.classList.remove('show');
        }
      });
    } catch (e) {
      console.error('Event listener setup error:', e);
    }
  },

  handleCardToggle(checkbox) {
    try {
      const group = checkbox.dataset.group;
      const device = checkbox.dataset.device;
      const cardId = `${group}-${device}`.toLowerCase();
      const isVisible = checkbox.checked;
      
      this.toggleCardVisibility(group, device, isVisible);
      this.saveVisibilityState(cardId, isVisible);
      
      if (state.autoResizeEnabled) {
        this.handlePostVisibilityResize();
      } else {
        const container = document.querySelector('.dashboard-container');
        if (container) {
          container.style.display = 'none';
          container.offsetHeight;
          container.style.display = 'grid';
        }
      }
    } catch (e) {
      console.error('Card toggle error:', e);
    }
  },

  saveVisibilityState(cardId, isVisible) {
    try {
      const visibility = utils.safeParseJSON(localStorage.getItem(CARD_VISIBILITY_KEY));
      visibility[cardId] = isVisible;
      localStorage.setItem(CARD_VISIBILITY_KEY, JSON.stringify(visibility));
    } catch (e) {
      console.error('Save visibility error:', e);
    }
  },

  handlePostVisibilityResize() {
    setTimeout(() => {
      try {
        dashboardResizer.resizeDashboard();
        
        const container = document.querySelector('.dashboard-container');
        if (!container) return;
        
        const scale = parseFloat(container.style.transform?.match(/scale\(([0-9.]+)\)/)?.[1]) || 1;
        if (scale < 0.7 && !state.pendingRefresh) {
          dashboardResizer.handleCriticalResize();
        }
      } catch (e) {
        console.error('Post visibility resize error:', e);
      }
    }, 100);
  }
};

// Theme Management Module
const themeManager = {
  init() {
    try {
      this.applySavedTheme();
      this.setupThemeSwitcher();
    } catch (e) {
      console.error('Theme init error:', e);
    }
  },

  applySavedTheme() {
    try {
      const savedTheme = localStorage.getItem('theme');
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      const theme = savedTheme || (prefersDark ? 'dark' : 'light');
      this.applyTheme(theme);
    } catch (e) {
      console.error('Apply saved theme error:', e);
    }
  },

  applyTheme(theme) {
    if (!THEMES[theme]) return;
    
    try {
      document.documentElement.removeAttribute('data-theme');
      document.documentElement.setAttribute('data-theme', theme);
      
      const themeBtn = document.getElementById('themeBtn');
      if (themeBtn) {
        const iconEl = themeBtn.querySelector('.btn-icon');
        if (iconEl) iconEl.textContent = THEMES[theme].icon;
        state.currentThemeIndex = Object.keys(THEMES).indexOf(theme);
      }
      
      localStorage.setItem('theme', theme);
    } catch (e) {
      console.error('Apply theme error:', e);
    }
  },

  setupThemeSwitcher() {
    try {
      const themeBtn = document.getElementById('themeBtn');
      if (!themeBtn) return;
      
      themeBtn.addEventListener('click', () => {
        const themeKeys = Object.keys(THEMES);
        state.currentThemeIndex = (state.currentThemeIndex + 1) % themeKeys.length;
        const nextTheme = themeKeys[state.currentThemeIndex];
        this.applyTheme(nextTheme);
      });
    } catch (e) {
      console.error('Theme switcher setup error:', e);
    }
  }
};

// Dashboard Resizer Module
const dashboardResizer = {
  init() {
    if (state.initialized) return;
    
    try {
      state.autoResizeEnabled = localStorage.getItem(AUTO_RESIZE_KEY) !== 'false';
      state.isMobile = window.innerWidth < MOBILE_BREAKPOINT;
      
      this.setupAutoResizeToggle();
      window.addEventListener('resize', utils.throttle(this.handleResize.bind(this), DEBOUNCE_DELAY));
      
      requestAnimationFrame(() => {
        this.initializeLayout();
      });
    } catch (e) {
      console.error('Resizer init error:', e);
    }
  },

  initializeLayout() {
    try {
      setTimeout(() => {
        localStorage.removeItem(RESIZE_REFRESHED_KEY);
      }, 10000);
      
      state.lastSize = {
        width: window.innerWidth,
        height: window.innerHeight
      };
      
      const container = document.querySelector('.dashboard-container');
      if (container) {
        container.style.transition = 'none';
        
        if (!state.autoResizeEnabled) {
          this.applyFixedLayout();
        }
      }
      
      this.resizeDashboard();
      
      setTimeout(() => {
        if (container) container.style.transition = '';
        state.initialized = true;
      }, 100);
    } catch (e) {
      console.error('Layout init error:', e);
    }
  },

  applyFixedLayout() {
    const container = document.querySelector('.dashboard-container');
    if (!container) return;
    
    try {
      container.classList.add('fixed-layout');
      utils.applyOptimalLayoutStyles(container, true);
      container.style.transform = '';
      container.style.transformOrigin = '';
    } catch (e) {
      console.error('Fixed layout error:', e);
    }
  },

// In the dashboardResizer module, update the resizeDashboard function:
resizeDashboard() {
  if (!state.autoResizeEnabled) {
    this.applyFixedLayout();
    return;
  }

  const container = document.querySelector('.dashboard-container');
  if (!container) return;

  try {
    container.classList.remove('fixed-layout');
    container.style.transition = 'transform 0.3s ease';
    
    // Reset styles for auto-fit mode
    container.style.width = '100%';
    container.style.maxWidth = 'none';
    container.style.padding = '10px';
    container.style.margin = '0';
    
    // Calculate available space
    const availableWidth = window.innerWidth;
    const availableHeight = window.innerHeight;
    
    // Get natural content dimensions
    const contentWidth = container.scrollWidth;
    const contentHeight = container.scrollHeight;
    
    // Calculate scale factors with minimum scale of 0.85 (85%)
    const widthScale = availableWidth / contentWidth;
    const heightScale = availableHeight / contentHeight;
    let scale = Math.min(widthScale, heightScale);
    scale = Math.max(0.85, Math.min(1, scale)); // Clamp between 0.85 and 1
    
    // Apply scaling if needed
    if (scale < 0.98) {
      container.style.transform = `scale(${scale})`;
      container.style.transformOrigin = 'top center';
    } else {
      container.style.transform = '';
    }
    
    // Force reflow for smoother transitions
    container.offsetHeight;
    
  } catch (e) {
    console.error('Resize error:', e);
  }
},

  handleCriticalResize() {
    if (!localStorage.getItem(RESIZE_REFRESHED_KEY)) {
      try {
        localStorage.setItem(RESIZE_REFRESHED_KEY, 'true');
        state.pendingRefresh = true;
        state.resizeCooldown = true;

        setTimeout(() => {
          window.location.reload();
          state.pendingRefresh = false;
        }, 500);

        setTimeout(() => state.resizeCooldown = false, REFRESH_COOLDOWN_DURATION);
      } catch (e) {
        console.error('Critical resize error:', e);
      }
    }
  },

  handleResize() {
    if (state.resizeCooldown) return;

    clearTimeout(state.resizeTimeout);
    state.resizeTimeout = setTimeout(() => {
      const widthChanged = Math.abs(window.innerWidth - state.lastSize.width) > 50;
      const heightChanged = Math.abs(window.innerHeight - state.lastSize.height) > 50;
      
      if (widthChanged || heightChanged || (window.innerWidth < MOBILE_BREAKPOINT !== state.isMobile)) {
        this.resizeDashboard();
      }
    }, DEBOUNCE_DELAY);
  },

  setupAutoResizeToggle() {
    const autoResizeBtn = document.getElementById('autoResizeBtn');
    if (!autoResizeBtn) return;

    this.updateAutoResizeButton();

    autoResizeBtn.addEventListener('click', (e) => {
      e.preventDefault();
      state.autoResizeEnabled = !state.autoResizeEnabled;
      
      try {
        localStorage.setItem(AUTO_RESIZE_KEY, state.autoResizeEnabled.toString());
      } catch (e) {
        console.error('LocalStorage error:', e);
      }
      
      this.updateAutoResizeButton();

      const container = document.querySelector('.dashboard-container');
      if (container) {
        container.style.transition = 'transform 0.3s ease';
        
        if (state.autoResizeEnabled) {
          container.classList.remove('fixed-layout');
          utils.resetLayoutStyles(container);
        } else {
          this.applyFixedLayout();
        }

        setTimeout(() => container.style.transition = '', 350);
      }

      setTimeout(() => {
        try {
          window.location.reload();
        } catch (e) {
          console.error('Reload error:', e);
        }
      }, 1000);
    });
  },

  updateAutoResizeButton() {
    const autoResizeBtn = document.getElementById('autoResizeBtn');
    if (!autoResizeBtn) return;

    const icon = autoResizeBtn.querySelector('.btn-icon');
    const label = autoResizeBtn.querySelector('.btn-label');
    
    if (icon) {
      icon.textContent = state.autoResizeEnabled ? '📐' : '✖️';
      icon.style.transition = 'transform 0.2s ease';
    }
    
    if (label) {
      label.textContent = state.autoResizeEnabled ? 'Auto Resize On' : 'Auto Resize Off';
    }
  }
};

// Reset Handler Module
const resetHandler = {
  init() {
    try {
      const resetBtn = document.getElementById('resetBtn');
      if (!resetBtn) return;

      resetBtn.addEventListener('click', this.handleReset.bind(this));
    } catch (e) {
      console.error('Reset handler init error:', e);
    }
  },

  async handleReset() {
    try {
      const [maxResponse, transferResponse] = await Promise.all([
        fetch('/reset_max_values/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': utils.getCookie('csrftoken')
          }
        }),
        fetch('/reset_transfer_data/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': utils.getCookie('csrftoken')
          }
        })
      ]);

      if (maxResponse.ok && transferResponse.ok) {
        this.showResetSuccess();
      } else {
        throw new Error('Reset failed');
      }
    } catch (e) {
      console.error('Reset error:', e);
    }
  },

  showResetSuccess() {
    try {
      const resetBtn = document.getElementById('resetBtn');
      if (!resetBtn) return;
      
      resetBtn.innerHTML = '<span class="btn-icon">✓</span> <span>Done</span>';
      setTimeout(() => {
        window.location.href = window.location.href;
      }, 500);
    } catch (e) {
      console.error('Reset success display error:', e);
    }
  }
};

// Stats Dropdown Module
const statsDropdown = {
  init() {
    try {
      document.querySelectorAll('.stats-select').forEach(select => {
        this.setupDropdown(select);
      });
    } catch (e) {
      console.error('Stats dropdown init error:', e);
    }
  },

  setupDropdown(select) {
    try {
      const type = select.dataset.type;
      const savedSelection = localStorage.getItem(`selected_${type}`);
      if (savedSelection) select.value = savedSelection;

      select.addEventListener('change', () => {
        this.handleDropdownChange(select);
      });
    } catch (e) {
      console.error('Dropdown setup error:', e);
    }
  },

  handleDropdownChange(select) {
    try {
      const type = select.dataset.type;
      const selectedDevice = select.value;
      localStorage.setItem(`selected_${type}`, selectedDevice);
      window.location.reload();
    } catch (e) {
      console.error('Dropdown change error:', e);
    }
  }
};

// Metrics Polling Module
const metricsPoller = {
  init() {
    try {
      this.updateTime();
      setInterval(this.updateTime.bind(this), 1000);
      this.pollMetrics();
    } catch (e) {
      console.error('Metrics poller init error:', e);
    }
  },

  updateTime() {
    try {
      const timeElement = document.getElementById('header-time');
      if (timeElement) {
        timeElement.textContent = new Date().toLocaleTimeString();
      }
    } catch (e) {
      console.error('Time update error:', e);
    }
  },

  async pollMetrics() {
    try {
      const res = await fetch('/get_metrics/');
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      
      const data = await res.json();
      this.updateMetrics(data);
      
      document.dispatchEvent(new CustomEvent('metricsUpdate', { detail: data }));
    } catch (e) {
      console.error('Polling error:', e);
    } finally {
      setTimeout(this.pollMetrics.bind(this), 1000);
    }
  },

  updateMetrics(data) {
    try {
      this.updateCpuMetrics(data);
      this.updateGpuMetrics(data);
      this.updateMemoryMetrics(data);
      this.updateNetworkMetrics(data);
    } catch (e) {
      console.error('Metrics update error:', e);
    }
  },

  updateCpuMetrics(data) {
    try {
      const selectedCpu = document.querySelector('.stats-select[data-type="cpu"]')?.value;
      const cpuData = data.cpu?.find(cpu => cpu.name === selectedCpu) || data.cpu?.[0];
      const element = document.getElementById('header-cpu-usage');
      
      if (cpuData && element) {
        element.textContent = `${cpuData.usage?.toFixed(1) || 0}%`;
      }
    } catch (e) {
      console.error('CPU metrics error:', e);
    }
  },

  updateGpuMetrics(data) {
    try {
      const selectedGpu = document.querySelector('.stats-select[data-type="gpu"]')?.value;
      const gpuData = data.gpu?.find(gpu => gpu.name === selectedGpu) || data.gpu?.[0];
      const element = document.getElementById('header-gpu-usage');
      
      if (gpuData && element) {
        element.textContent = `${gpuData.core?.toFixed(1) || 0}%`;
      }
    } catch (e) {
      console.error('GPU metrics error:', e);
    }
  },

  updateMemoryMetrics(data) {
    try {
      const element = document.getElementById('header-ram-usage');
      if (data.memory && element) {
        element.textContent = `${data.memory.usage?.toFixed(1) || 0}%`;
      }
    } catch (e) {
      console.error('Memory metrics error:', e);
    }
  },

  updateNetworkMetrics(data) {
    try {
      const selectedNetwork = document.querySelector('.stats-select[data-type="network"]')?.value;
      const networkData = data.network?.interfaces?.find(nic =>
        nic.name === selectedNetwork || nic.interface === selectedNetwork
      ) || data.network?.interfaces?.[0];
      const element = document.getElementById('header-network-usage');
      
      if (networkData && element) {
        const sent = utils.formatBytes(networkData.bytes_sent || 0);
        const recv = utils.formatBytes(networkData.bytes_recv || 0);
        element.textContent = `↑ ${sent} ↓ ${recv}`;
      }
    } catch (e) {
      console.error('Network metrics error:', e);
    }
  }
};

// Main Initialization
document.addEventListener('DOMContentLoaded', () => {
  try {
    // Initialize core modules first
    dashboardResizer.init();
    themeManager.init();
    
    // Initialize other modules
    cardVisibility.init();
    resetHandler.init();
    statsDropdown.init();
    metricsPoller.init();
  } catch (e) {
    console.error('Main initialization error:', e);
  }
});