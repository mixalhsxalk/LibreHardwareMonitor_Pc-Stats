import os
import json
import time
import psutil
import requests
from pathlib import Path
from datetime import datetime
from threading import Lock
from typing import Dict, List, Optional, Union
from django.conf import settings

class JSONSensorMonitor:
    def __init__(self):
        self.cache = {}
        self.cache_lock = Lock()
        self.last_updated = 0
        self.refresh_interval = 1.0
        
        self.max_values = {
            'cpu': {'usage': 0, 'temp': 0, 'power': 0, 'voltage': 0},
            'gpu': {'core': 0, 'memory': 0, 'temp': 0, 'hotspot': 0, 'power': 0}, 
            'memory': {'usage': 0},
            'disk': {'read': 0, 'write': 0, 'temp': 0},
            'network': {'download': 0, 'upload': 0},
            'battery': {'charge': 0, 'power': 0, 'voltage': 0}
        }
        self.max_lock = Lock()

    def _fetch_json_data(self) -> Optional[dict]:
        """Fetch data from LHM API with proper error handling"""
        url = getattr(settings, 'LHM_API_URL', 'http://localhost:8085/data.json')
        try:
            response = requests.get(url, timeout=2.0)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"[API] Connection error: {str(e)}")
            return None
        except json.JSONDecodeError:
            print("[API] Invalid JSON response")
            return None

    def _refresh_cache(self):
        """Refresh cached data with thread safety"""
        data = self._fetch_json_data()
        if not data:
            print("[Cache] Failed to refresh - no data received")
            return

        flat_data = {}
        
        def flatten_sensors(node, path=""):
            if not isinstance(node, dict):
                return
                
            label = node.get("Text", "").replace('\x00', '').strip()
            sensor_type = node.get("Type")
            value = node.get("Value")
            
            if all([label, sensor_type, value is not None]):
                flat_data[f"{path}/{label}" if path else label] = {
                    'value': value,
                    'type': sensor_type
                }

            for child in node.get("Children", []):
                flatten_sensors(child, f"{path}/{label}" if path else label)

        flatten_sensors(data)
        
        with self.cache_lock:
            self.cache = flat_data
            self.last_updated = time.time()

    def get_sensor_value(self, device_name: str, sensor_name: str, sensor_type: str = None) -> float:
        """Get sensor value with debug logging"""
        if time.time() - self.last_updated > self.refresh_interval:
            self._refresh_cache()

        with self.cache_lock:
            for path, sensor in self.cache.items():
                path_lower = path.lower()
                matches_device = device_name.lower() in path_lower
                matches_sensor = sensor_name.lower() in path_lower
                matches_type = (not sensor_type or 
                            sensor_type.lower() == sensor['type'].lower())
                
                if matches_device and matches_sensor and matches_type:
                    try:
                        raw_value = str(sensor['value']).replace(",", ".").strip()
                        parts = raw_value.split()
                        value = float(parts[0])
                        unit = parts[1].lower() if len(parts) > 1 else ""

                        if unit == "kb/s":
                            value *= 1024
                        elif unit == "mb/s":
                            value *= 1024 * 1024

                        return value
                    except (ValueError, IndexError, AttributeError):
                        print(f"[Sensor] Error parsing value: {path}")
                        continue
        
        return 0.0

    def get_avg_cpu_core_voltage(self) -> float:
        """Get average voltage across all CPU cores"""
        if time.time() - self.last_updated > self.refresh_interval:
            self._refresh_cache()

        voltages = []
        with self.cache_lock:
            for path, sensor in self.cache.items():
                if "CPU Core #" in path and "Voltage" in path:
                    try:
                        value = str(sensor['value']).replace(",", ".").split()[0]
                        voltages.append(float(value))
                    except (ValueError, AttributeError):
                        continue
        
        return sum(voltages) / len(voltages) if voltages else 0.0

    def get_avg_cpu_core_load(self) -> float:
        """Get average load across all CPU cores"""
        if time.time() - self.last_updated > self.refresh_interval:
            self._refresh_cache()

        loads = []
        with self.cache_lock:
            for path, sensor in self.cache.items():
                if "CPU Core #" in path and sensor['type'].lower() == "load":
                    try:
                        value = str(sensor['value']).replace(",", ".").split()[0]
                        loads.append(float(value))
                    except (ValueError, AttributeError):
                        continue
        
        return sum(loads) / len(loads) if loads else 0.0

    def update_max_values(self, metrics: dict):
        """Update max values tracking in a thread-safe way"""
        with self.max_lock:
            # CPU
            for cpu in metrics.get('cpu', []):
                for metric in ['usage', 'temp', 'power', 'voltage','hotspot']:
                    if metric in cpu and cpu[metric] > self.max_values['cpu'].get(metric, 0):
                        self.max_values['cpu'][metric] = cpu[metric]
            
            # GPU
            for gpu in metrics.get('gpu', []):
                for metric in ['core', 'temp', 'power']:
                    if metric in gpu and gpu[metric] > self.max_values['gpu'].get(metric, 0):
                        self.max_values['gpu'][metric] = gpu[metric]
            
            # Disk
            for disk in metrics.get('disk', {}).get('devices', []):
                if disk['read'] > self.max_values['disk']['read']:
                    self.max_values['disk']['read'] = disk['read']
                if disk['write'] > self.max_values['disk']['write']:
                    self.max_values['disk']['write'] = disk['write']
                if disk['temp'] > self.max_values['disk']['temp']:
                    self.max_values['disk']['temp'] = disk['temp']
            
            # Network
            for nic in metrics.get('network', {}).get('interfaces', []):
                if nic['download'] > self.max_values['network']['download']:
                    self.max_values['network']['download'] = nic['download']
                if nic['upload'] > self.max_values['network']['upload']:
                    self.max_values['network']['upload'] = nic['upload']

            # Battery
            for battery in metrics.get('battery', []):
                for metric in ['charge', 'power', 'voltage']:
                    if metric in battery and battery[metric] > self.max_values['battery'].get(metric, 0):
                        self.max_values['battery'][metric] = battery[metric]

    def reset_max_values(self):
        """Reset all max values to 0"""
        with self.max_lock:
            for category in self.max_values:
                for metric in self.max_values[category]:
                    self.max_values[category][metric] = 0


class MetricCollector:
    _instance = None
    _lock = Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
            
        self._initialized = True
        self.sensor_monitor = JSONSensorMonitor()
        self._init_network_counters()
        self.system_drive = os.getenv("SystemDrive", "C:") + "\\"
        self.device_map = self._load_device_map()
        self.category_devices = self._group_devices_by_category()

    def _init_network_counters(self):
        """Initialize network tracking"""
        current_net = psutil.net_io_counters(pernic=True)
        self.prev_net = {iface: {
            'sent': counters.bytes_sent,
            'recv': counters.bytes_recv
        } for iface, counters in current_net.items()}
        
        self.transfer_offset = {iface: {
            'sent': counters.bytes_sent,
            'recv': counters.bytes_recv
        } for iface, counters in current_net.items()}
        self.prev_net_time = time.time()

    def _load_device_map(self) -> dict:
        """Load and validate device category map with battery support"""
        path = Path("device_category_map.json")
        if not path.exists():
            print("[DeviceMap] File not found - using fallback detection")
            return self._get_fallback_device_map()
        
        try:
            with open(path, 'r') as f:
                return {
                    k.replace('\x00', '').strip(): v
                    for k, v in json.load(f).items()
                }
        except Exception as e:
            print(f"[DeviceMap] Error loading: {str(e)}")
            return {}

    def _get_fallback_device_map(self) -> dict:
        """Fallback device detection when map file is missing"""
        data = self.sensor_monitor._fetch_json_data()
        if not data:
            return {}
            
        device_map = {}
        keyword_map = {
            "CPU": ["intel", "amd", "ryzen", "core"],
            "GPU": ["nvidia", "geforce", "radeon"],
            "Storage": ["samsung", "wd", "seagate"],
            "Network": ["ethernet", "wifi", "realtek"]
        }

        def scan_node(node):
            name = node.get("Text", "")
            for category, keywords in keyword_map.items():
                if any(k.lower() in name.lower() for k in keywords):
                    device_map[name] = category
                    break
            for child in node.get("Children", []):
                scan_node(child)

        scan_node(data)
        return device_map

    def _group_devices_by_category(self) -> dict:
        """Organize devices by standardized categories"""
        categories = {
            'cpu': [],
            'gpu': [],
            'memory': ["System RAM"],
            'disk': [],
            'network': [],
            'battery': []
        }
        
        category_mapping = {
            'CPU': 'cpu',
            'GPU': 'gpu',
            'Storage': 'disk',
            'Network': 'network'
        }

        for device, category in self.device_map.items():
            normalized_category = category_mapping.get(category)
            if normalized_category:
                categories[normalized_category].append(device)
                
        return categories

    def collect_metrics(self) -> dict:
        """Main metrics collection method"""
        metrics = {
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'cpu': self._collect_cpu_metrics(),
            'gpu': self._collect_gpu_metrics(),
            'memory': self._collect_memory_metrics(),
            'disk': self._collect_disk_metrics(),
            'network': self._collect_network_metrics(),
            'battery': self._collect_battery_metrics(),
            'max_values': self.sensor_monitor.max_values
        }
        
        self.sensor_monitor.update_max_values(metrics)
        return metrics

    def _collect_cpu_metrics(self) -> List[dict]:
        """Collect metrics for all CPU devices"""
        metrics = []
        for device in self.category_devices['cpu']:
            # Try multiple possible sensor names
            usage = (self.sensor_monitor.get_sensor_value(device, "CPU Total", "Load") or
                    self.sensor_monitor.get_sensor_value(device, "CPU Package", "Load") or
                    self.sensor_monitor.get_sensor_value(device, "CPU Cores", "Load") or
                    psutil.cpu_percent(interval=0.1))
            
            temp = (self.sensor_monitor.get_sensor_value(device, "CPU Package", "Temperature") or
                self.sensor_monitor.get_sensor_value(device, "Core Max", "Temperature") or
                self.sensor_monitor.get_sensor_value(device, "Tdie", "Temperature"))
            
            power = self.sensor_monitor.get_sensor_value(device, "Package", "Power")
            voltage = (self.sensor_monitor.get_sensor_value(device, "Core", "Voltage") or
                    self.sensor_monitor.get_avg_cpu_core_voltage())

            metrics.append({
                'name': device,
                'usage': usage,
                'temp': temp,
                'power': power,
                'voltage': voltage,
                'avg_core_load': self.sensor_monitor.get_avg_cpu_core_load()
            })
        
        return metrics if metrics else [{
            'name': "CPU",
            'usage': psutil.cpu_percent(interval=0.1),
            'temp': 0,
            'power': 0,
            'voltage': self.sensor_monitor.get_avg_cpu_core_voltage(),
            'avg_core_load': self.sensor_monitor.get_avg_cpu_core_load()
        }]

    def _collect_gpu_metrics(self) -> List[dict]:
        """Collect metrics for all GPU devices"""
        metrics = []
        for device in self.category_devices['gpu']:
            core_load = (self.sensor_monitor.get_sensor_value(device, "GPU Core", "Load") or
                    self.sensor_monitor.get_sensor_value(device, "3D", "Load") or
                    self.sensor_monitor.get_sensor_value(device, "D3D", "Load"))
            
            temp = (self.sensor_monitor.get_sensor_value(device, "GPU Core", "Temperature") or
                self.sensor_monitor.get_sensor_value(device, "GPU", "Temperature"))
            
            metrics.append({
                'name': device,
                'core': core_load,
                'memory': self.sensor_monitor.get_sensor_value(device, "GPU Memory", "Load"),
                'temp': temp,
                'power': self.sensor_monitor.get_sensor_value(device, "GPU", "Power"),
                'hotspot': (self.sensor_monitor.get_sensor_value(device, "Hotspot", "Temperature") or
                        self.sensor_monitor.get_sensor_value(device, "Hot Spot", "Temperature") or
                        self.sensor_monitor.get_sensor_value(device, "Junction", "Temperature"))
            })
        
        return metrics if metrics else [{
            'name': "GPU",
            'core': 0,
            'memory': 0,
            'temp': 0,
            'hotspot': 0,
            'power': 0
        }]

    def _collect_memory_metrics(self) -> dict:
        """Collect system memory metrics"""
        mem = psutil.virtual_memory()
        return {
            'name': "System RAM",
            'usage': mem.percent,
            'total': mem.total,
            'used': mem.used,
            'free': mem.free
        }

    def _collect_disk_metrics(self) -> dict:
        """Collect disk metrics using only LHM (temperature + read/write throughput)"""
        disks = []

        for lhm_disk in self.category_devices['disk']:
            temp = self.sensor_monitor.get_sensor_value(lhm_disk, "Temperature", "Temperature") or \
                self.sensor_monitor.get_sensor_value(lhm_disk, "Temperature 2", "Temperature")
            
            read_rate = self.sensor_monitor.get_sensor_value(lhm_disk, "Read Rate", "Throughput")
            write_rate = self.sensor_monitor.get_sensor_value(lhm_disk, "Write Rate", "Throughput")

            if read_rate < 1024:
                read_rate *= 1024
            if write_rate < 1024:
                write_rate *= 1024

            disks.append({
                'name': lhm_disk,
                'temp': temp,
                'read': read_rate,
                'write': write_rate,
                'device': lhm_disk
            })

        return {'devices': disks}

    def _collect_network_metrics(self) -> dict:
        """Collect metrics for all network interfaces"""
        psutil_net = self._get_network_usage()
        interfaces = []
        
        for device in self.category_devices['network']:
            interfaces.append({
                'name': device,
                'speed': self.sensor_monitor.get_sensor_value(device, "Speed"),
                'upload': 0,
                'download': 0,
                'bytes_sent': 0,
                'bytes_recv': 0,
                'interface': device
            })
        
        for iface, net_data in psutil_net.items():
            matching_nic = next((nic for nic in interfaces 
                              if iface.lower() in nic['name'].lower() or 
                              nic['name'].lower() in iface.lower()), None)
            
            if matching_nic:
                matching_nic.update({
                    'upload': net_data['upload_speed'],
                    'download': net_data['download_speed'],
                    'bytes_sent': net_data['bytes_sent'],
                    'bytes_recv': net_data['bytes_recv'],
                    'interface': iface
                })
            elif net_data['upload_speed'] + net_data['download_speed'] > 0:
                interfaces.append({
                    'name': iface,
                    'speed': 0,
                    'upload': net_data['upload_speed'],
                    'download': net_data['download_speed'],
                    'bytes_sent': net_data['bytes_sent'],
                    'bytes_recv': net_data['bytes_recv'],
                    'interface': iface
                })
        
        return {'interfaces': interfaces}

    def _get_network_usage(self) -> dict:
        """Get network usage statistics"""
        current_time = time.time()
        current_net = psutil.net_io_counters(pernic=True)
        
        if not hasattr(self, 'prev_net') or not hasattr(self, 'prev_net_time'):
            self.prev_net = {iface: {'sent': counters.bytes_sent, 'recv': counters.bytes_recv} 
                            for iface, counters in current_net.items()}
            self.prev_net_time = current_time
            return {}

        time_diff = max(current_time - self.prev_net_time, 0.1)
        
        usage = {}
        for iface, counters in current_net.items():
            prev = self.prev_net.get(iface, {'sent': 0, 'recv': 0})
            offset = self.transfer_offset.get(iface, {'sent': 0, 'recv': 0})
            
            usage[iface] = {
                'upload_speed': max(0, (counters.bytes_sent - prev['sent']) / time_diff),
                'download_speed': max(0, (counters.bytes_recv - prev['recv']) / time_diff),
                'bytes_sent': counters.bytes_sent - offset['sent'],
                'bytes_recv': counters.bytes_recv - offset['recv'],
                'interface': iface
            }
        
        self.prev_net = {iface: {'sent': c.bytes_sent, 'recv': c.bytes_recv} 
                        for iface, c in current_net.items()}
        self.prev_net_time = current_time
        return usage
    
    def _collect_battery_metrics(self) -> List[dict]:
        """Collect battery metrics"""
        metrics = []
        for device in self.category_devices.get('battery', []):
            try:
                charge = self.sensor_monitor.get_sensor_value(device, "Charge Level", "Level")
                if charge is None:
                    continue
                    
                metrics.append({
                    "name": device,
                    "charge": charge,
                    "power": self.sensor_monitor.get_sensor_value(device, "Power", "Power") or 0,
                    "voltage": self.sensor_monitor.get_sensor_value(device, "Voltage", "Voltage") or 0
                })
            except Exception as e:
                print(f"[Battery] Error collecting metrics for {device}: {str(e)}")
                continue
            
        return metrics

    @classmethod
    def reset_max_cache(cls):
        instance = cls()
        instance.sensor_monitor.reset_max_values()

    @classmethod
    def reset_transfer_data(cls):
        instance = cls()
        instance._init_network_counters()