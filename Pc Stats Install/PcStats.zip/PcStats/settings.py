import os

LHM_URL = os.getenv("LHM_API_URL", "http://localhost:8085/data.json")
LHM_API_URL = "http://localhost:8085/data.json"

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

SECRET_KEY = 'django-insecure-your-secret-key-here'

DEBUG = True

ALLOWED_HOSTS = ['*']

INSTALLED_APPS = [
    'django.contrib.staticfiles',
    'PcStats',
    'channels',  # Must include channels
]

MIDDLEWARE = [
    'django.middleware.common.CommonMiddleware',
]

CHANNEL_LAYERS = {
    "default": {
        "BACKEND": "channels.layers.InMemoryChannelLayer",
        "CONFIG": {
            "capacity": 1000,  # Increase if needed
            "expiry": 10,      # Message expiry in seconds
        },
    },
}

ROOT_URLCONF = 'PcStats.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.template.context_processors.static',
            ],
        },
    },
]

CORS_ALLOW_ALL_ORIGINS = True  # For development only

WSGI_APPLICATION = 'PcStats.wsgi.application'


# Static files (CSS, JavaScript, Images)
STATIC_URL = 'static/'

STATICFILES_DIRS = [
    os.path.join(BASE_DIR, 'PcStats', 'static'),
]

# For production (when you run collectstatic)
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')


ASGI_APPLICATION = 'PcStats.asgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': ':memory:',  # Use in-memory DB (nothing is saved)
    }
}


# Time zone settings
TIME_ZONE = 'UTC'
USE_TZ = True
